# P2_DOM_Extraction

(Your prompt list for DOM extraction...)