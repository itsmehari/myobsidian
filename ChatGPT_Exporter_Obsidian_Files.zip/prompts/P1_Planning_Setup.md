# P1_Planning_Setup

(Your prompt list for planning & setup...)